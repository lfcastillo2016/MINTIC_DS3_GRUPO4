using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Comarico2.App.Dominio;

namespace Comarico2.App.Presentacion.Pages

{
    public class ListModel : PageModel
    {
        public IEnumerable<Cliente> clientes {get;set;}
        public ListModel()
{
            clientes = new List<Cliente>()
            {
                new Cliente{id=1, cedula="1745454545", nombre="Nelson Torres"},
                new Cliente{id=2, cedula="3121211",    nombre="Daniel Ocampo"},
                new Cliente{id=3, cedula="12111122",   nombre="Edwin Rojas"},
                new Cliente{id=4, cedula="7878454",    nombre="Luis Felipe Castillo"}
            };  
        }
        public void OnGet()
        {
        }
    }
}
