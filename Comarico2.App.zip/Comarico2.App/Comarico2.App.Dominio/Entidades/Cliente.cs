using System;

namespace Comarico2.App.Dominio
{
    public class Cliente
    {
    public int id { get; set;}   
    public string cedula { get; set;}   
    public string nombre { get; set;}   
    public string direccion { get; set;}   
    public string telefono { get; set;}   
    }
}