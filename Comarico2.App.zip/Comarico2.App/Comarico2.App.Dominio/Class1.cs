﻿using System;

namespace Comarico2.App.Dominio
{
    public class Class1
    {
    }
}
