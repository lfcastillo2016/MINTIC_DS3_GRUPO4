using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.EntityFrameworkCore;
using Comarico2.App.Dominio;

namespace Comarico2.App.Persistencia.AppRepositorios
{
    public class RepositorioCliente : IRepositorioCliente
    {
       private readonly AppContext _appContext;
       public RepositorioCliente(AppContext appContext)
        {
            _appContext = appContext;
        }
        Cliente IRepositorioCliente.AddCliente(Cliente cliente)
        {
        try
          {
            var ClienteAdicionado = _appContext.Clientes.Add( cliente );  //INSERT en la BD
            _appContext.SaveChanges();                  
            return ClienteAdicionado.Entity;
          }
          catch
            {
                throw;
            }
        }

        IEnumerable<Cliente> IRepositorioCliente.GetAllClientes()
        {
            return _appContext.Clientes;
        }
       Cliente IRepositorioCliente.GetCliente(int? idCliente)
       {
            return _appContext.Clientes.FirstOrDefault(p => p.id == idCliente);
       }

       Cliente IRepositorioCliente.UpdateCliente(Cliente cliente)
        {
            var ClienteEncontrado = _appContext.Clientes.FirstOrDefault(p => p.id == cliente.id);
            if (ClienteEncontrado != null)
            {
                ClienteEncontrado.cedula  = cliente.cedula;
                ClienteEncontrado.nombre  = cliente.nombre;
                _appContext.SaveChanges();
            }
            return ClienteEncontrado;
        }

        void IRepositorioCliente.DeleteCliente(int idCliente)
        {
            var ClienteEncontrado = _appContext.Clientes.FirstOrDefault(p => p.id == idCliente);
            if (ClienteEncontrado == null)
                return;
            _appContext.Clientes.Remove(ClienteEncontrado);
            _appContext.SaveChanges();
        }

    }
}
