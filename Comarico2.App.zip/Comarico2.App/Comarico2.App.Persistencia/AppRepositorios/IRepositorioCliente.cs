using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using Comarico2.App.Dominio;

namespace Comarico2.App.Persistencia.AppRepositorios
{
    //public class IRepositorioCliente
    public interface IRepositorioCliente
    {
        Cliente AddCliente(Cliente cliente);
        IEnumerable<Cliente> GetAllClientes();         
        Cliente GetCliente(int? idCliente);
        Cliente UpdateCliente(Cliente cliente);
        void DeleteCliente(int idCliente); 
    }
}