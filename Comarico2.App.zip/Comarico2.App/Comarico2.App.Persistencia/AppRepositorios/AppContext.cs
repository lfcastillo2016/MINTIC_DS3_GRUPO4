using Microsoft.EntityFrameworkCore;
using Comarico2.App.Dominio;

namespace Comarico2.App.Persistencia.AppRepositorios
{
    public class AppContext  :  DbContext
    {
     public DbSet<Cliente> Clientes { get; set; }
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
                optionsBuilder.UseSqlServer("Data Source=COMARICO; Initial Catalog=Comarico; User id=sa; password=12345; ");
                
            }
        }
    }    
}